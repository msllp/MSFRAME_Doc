<div class='browser-window'>
	<div class='top-bar'>
		<div class='circles'>
			<div class="circle circle-red"></div>
			<div class="circle circle-yellow"></div>
			<div class="circle circle-green"></div>
		</div>
	</div>
	<div class='window-content'>
		<pre class="line-numbers"><code class="language-php">
&lt;?php


class Idea extends Eloquent
{

	/**
	 * Dreaming of something more?
	 *
	 * @with Laravel
	 */
	public function create()
	{
		// Have a fresh start...
	}

}</code></pre>
	</div>
</div>

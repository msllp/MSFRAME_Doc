<div class="the-404">
    <div class="contain">
        <div class="media">
            <img src="/assets/img/lamp-post.jpg">
        </div>
        <div class="content pl-6">
            <h3>You seem to have upset the delicate internal balance of my housekeeper.</h3>
        </div>
    </div>
</div>

<?php return array (
  'vinkla/algolia' => 
  array (
    'providers' => 
    array (
      0 => 'Vinkla\\Algolia\\AlgoliaServiceProvider',
    ),
    'aliases' => 
    array (
      'Algolia' => 'Vinkla\\Algolia\\Facades\\Algolia',
    ),
  ),
);